def return_string():
    raise Exception("Sorry, This is exception from python script")
    return "Hello from Python!"
