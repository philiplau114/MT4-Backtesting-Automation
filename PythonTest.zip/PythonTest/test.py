def run_script():
    try:
        # Thowing exception
        raise Exception("Sample Exception, This is exception from python script")
    except Exception as e:
        result = str(e)
    return result